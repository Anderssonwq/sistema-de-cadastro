document.addEventListener("DOMContentLoaded", function () {
    const estadoSelect = document.getElementById("estado");
    const cidadeSelect = document.getElementById("cidade");
    const regiaoSelect = document.getElementById("regiao");

    // Mapeamento de estados por região (nomes completos)
    const estadosPorRegiao = {
        "Norte": [
            { nome: "Acre" },
            { nome: "Amapá" },
            { nome: "Amazonas" },
            { nome: "Pará" },
            { nome: "Rondônia" },
            { nome: "Roraima" },
            { nome: "Tocantins" }
        ],
        "Nordeste": [
            { nome: "Alagoas" },
            { nome: "Bahia" },
            { nome: "Ceará" },
            { nome: "Espírito Santo" },
            { nome: "Maranhão" },
            { nome: "Paraíba" },
            { nome: "Pernambuco" },
            { nome: "Piauí" },
            { nome: "Rio de Janeiro" },
            { nome: "Rio Grande do Norte" },
            { nome: "Rio Grande do Sul" }
        ],
        "Centro-Oeste": [
            { nome: "Goiás" },
            { nome: "Mato Grosso do Sul" },
            { nome: "Mato Grosso" },
            { nome: "Distrito Federal" }
        ],
        "Sudeste": [
            { nome: "Minas Gerais" },
            { nome: "São Paulo" },
            { nome: "Rio de Janeiro" },
            { nome: "Espírito Santo" }
        ],
        "Sul": [
            { nome: "Paraná" },
            { nome: "Rio Grande do Sul" },
            { nome: "Santa Catarina" }
        ]
    };

    // Preenche os estados quando a região é alterada
    regiaoSelect.addEventListener("change", function () {
        const regiao = regiaoSelect.value;
        estadoSelect.innerHTML = "<option value=''>Selecione o estado</option>"; // Limpa o campo de estado
        cidadeSelect.innerHTML = "<option value=''>Selecione a cidade</option>"; // Limpa o campo de cidade

        if (regiao && estadosPorRegiao[regiao]) {
            const estados = estadosPorRegiao[regiao];
            estados.forEach(estado => {
                const option = document.createElement("option");
                option.value = estado.nome;
                option.textContent = estado.nome;
                estadoSelect.appendChild(option);
            });
        }
    });

    // Preenche as cidades quando o estado é alterado
    estadoSelect.addEventListener("change", function () {
        const estado = estadoSelect.value;
        cidadeSelect.innerHTML = "<option value=''>Selecione a cidade</option>"; // Limpa o campo de cidade

        if (estado) {
            // Faz a requisição das cidades baseadas no estado selecionado
            const estadoCodigo = getEstadoCodigo(estado); // Obtém o código do estado

            if (!estadoCodigo) {
                console.error("Código de estado não encontrado.");
                cidadeSelect.innerHTML = "<option value=''>Erro ao carregar as cidades</option>";
                return;
            }

            // Faz a requisição da API
            fetch(`https://brasilapi.com.br/api/ibge/municipios/v1/${estadoCodigo}`)
                .then(response => response.json())
                .then(cidades => {
                    if (Array.isArray(cidades)) {
                        cidades.forEach(cidade => {
                            const option = document.createElement("option");
                            option.value = cidade.nome;
                            option.textContent = cidade.nome;
                            cidadeSelect.appendChild(option);
                        });
                    } else {
                        cidadeSelect.innerHTML = "<option value=''>Erro ao carregar as cidades</option>";
                    }
                })
                .catch(error => {
                    console.error("Erro ao carregar as cidades:", error);
                    cidadeSelect.innerHTML = "<option value=''>Erro ao carregar as cidades</option>";
                });
        }
    });

    // Função que retorna o código do estado
    function getEstadoCodigo(estado) {
        const estadoMap = {
            "Acre": "AC",
            "Amapá": "AP",
            "Amazonas": "AM",
            "Pará": "PA",
            "Rondônia": "RO",
            "Roraima": "RR",
            "Tocantins": "TO",
            "Alagoas": "AL",
            "Bahia": "BA",
            "Ceará": "CE",
            "Espírito Santo": "ES",
            "Maranhão": "MA",
            "Paraíba": "PB",
            "Pernambuco": "PE",
            "Piauí": "PI",
            "Rio de Janeiro": "RJ",
            "Rio Grande do Norte": "RN",
            "Rio Grande do Sul": "RS",
            "Goiás": "GO",
            "Mato Grosso do Sul": "MS",
            "Mato Grosso": "MT",
            "Distrito Federal": "DF",
            "Minas Gerais": "MG",
            "São Paulo": "SP",
            "Espírito Santo": "ES",
            "Santa Catarina": "SC",
            "Paraná": "PR",
            "Rio Grande do Sul": "RS"
        };

        return estadoMap[estado] || null;
    }
});
