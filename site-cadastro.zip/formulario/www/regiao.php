<?php
// Lista de regiões do Brasil
$regioes = [
    "Norte",
    "Nordeste",
    "Centro-Oeste",
    "Sudeste",
    "Sul"
];

// Retorna as regiões no formato JSON
header('Content-Type: application/json');
echo json_encode($regioes);
?>
