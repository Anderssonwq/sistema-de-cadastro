<?php
// Iniciar a sessão
session_start();

// Verificar se o usuário está logado
if (!isset($_SESSION['user'])) {
    header("Location: login.html"); // Redireciona para a página de login se não estiver logado
    exit();
}

// Recuperar dados do usuário logado
$user = $_SESSION['user'];
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Painel do Usuário</title>
    <link rel="stylesheet" href="painel.css">
</head>
<body>

    <div class="panel-container">
        <div class="panel-header">
            <h1>Bem-vindo, <?php echo $user['nome']; ?>!</h1>
            <p>Este é o seu painel de controle.</p>
        </div>

        <div class="panel-content">
            <h2>Informações do Usuário</h2>
            <table>
                <tr>
                    <th>Email</th>
                    <td><?php echo $user['email']; ?></td>
                </tr>
                <tr>
                    <th>Nome de Usuário</th>
                    <td><?php echo $user['usuario']; ?></td>
                </tr>
                <tr>
                    <th>Região</th>
                    <td><?php echo $user['regiao']; ?></td>
                </tr>
                <tr>
                    <th>Estado</th>
                    <td><?php echo $user['estado']; ?></td>
                </tr>
                <tr>
                    <th>Cidade</th>
                    <td><?php echo $user['cidade']; ?></td>
                </tr>
            </table>
            <a href="logout.php" class="logout-btn">Sair</a>
        </div>
    </div>

</body>
</html>
