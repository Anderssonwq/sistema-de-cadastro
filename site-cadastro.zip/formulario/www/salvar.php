<?php
// Iniciar a sessão
session_start();

// Configuração de conexão com o banco de dados
$servername = "mysql_server";  // Nome do serviço MySQL no Docker Compose (usado como hostname)
$username = "root";            // Usuário do MySQL
$password = "root";   // Senha do MySQL
$dbname = "meubanco";          // Nome do banco de dados

try {
    // Estabelecendo a conexão com o banco de dados MySQL
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    
    // Definir o modo de erro do PDO para exceções
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // Se a conexão for bem-sucedida, exibe a mensagem
    // echo "Conexão bem-sucedida!";
} catch(PDOException $e) {
    // Caso ocorra algum erro na conexão, exibe a mensagem
    echo "Erro de conexão: " . $e->getMessage();
    exit();
}

// Verificar se o formulário foi enviado
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Recuperar os dados enviados pelo formulário
    $nome = $_POST['nome'];
    $regiao = $_POST['regiao'];
    $estado = $_POST['estado'];
    $cidade = $_POST['cidade'];
    $usuario = $_POST['usuario'];
    $senha = password_hash($_POST['senha'], PASSWORD_DEFAULT); // Criptografar a senha
    $email = $_POST['email'];

    // Preparar a consulta SQL para inserir os dados no banco de dados
    $sql = "INSERT INTO usuarios (nome, regiao, estado, cidade, usuario, senha, email) 
            VALUES (:nome, :regiao, :estado, :cidade, :usuario, :senha, :email)";
    
    // Preparar a execução da consulta
    $stmt = $conn->prepare($sql);
    
    // Vincular os parâmetros à consulta SQL
    $stmt->bindParam(':nome', $nome);
    $stmt->bindParam(':regiao', $regiao);
    $stmt->bindParam(':estado', $estado);
    $stmt->bindParam(':cidade', $cidade);
    $stmt->bindParam(':usuario', $usuario);
    $stmt->bindParam(':senha', $senha);
    $stmt->bindParam(':email', $email);

    // Executar a consulta e verificar se foi bem-sucedida
    if ($stmt->execute()) {
        // Mensagem de sucesso
        header("Location: sucesso-cadastro.html");
    } else {
        // Mensagem de erro, caso a consulta falhe
        echo "Erro ao cadastrar o usuário. Tente novamente.";
    }
}

// Fechar a conexão com o banco de dados
$conn = null;
?>

