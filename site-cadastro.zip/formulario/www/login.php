<?php
// Iniciar a sessão
session_start();

// Configuração de conexão com o banco de dados
$servername = "mysql_server";  // Nome do serviço MySQL no Docker Compose (usado como hostname)
$username = "root";            // Usuário do MySQL
$password = "root";   // Senha do MySQL
$dbname = "meubanco";          // Nome do banco de dados

try {
    // Estabelecendo a conexão com o banco de dados MySQL
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    
    // Definir o modo de erro do PDO para exceções
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
} catch(PDOException $e) {
    // Caso ocorra algum erro na conexão, exibe a mensagem
    echo "Erro de conexão: " . $e->getMessage();
    exit();
}

// Verificar se o formulário foi enviado
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Recuperar os dados do formulário
    $email = $_POST['email'];
    $senha = $_POST['senha'];

    // Preparar a consulta SQL para verificar se o usuário existe
    $sql = "SELECT * FROM usuarios WHERE email = :email LIMIT 1";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':email', $email);

    // Executar a consulta
    $stmt->execute();
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user && password_verify($senha, $user['senha'])) {
        // Autenticação bem-sucedida, criar a sessão do usuário
        $_SESSION['user'] = $user;
        header("Location: painel.php"); // Redirecionar para o painel do usuário
        exit();
    } else {
        echo "Email ou senha inválidos.";
    }
}

// Fechar a conexão com o banco de dados
$conn = null;
?>
